
public class Score {
	
	private double score;
	
	public Score(){
		score = 0;
	}
	
	public void changeScore(double change){
		score += change;
	}
}
