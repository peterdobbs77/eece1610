
public class Bomb {
	
	//random starting position
	//random starting angle
	//
	
	public Bomb(double position, double angle, double velocity){
		//make bomb
	}
	
	public void bombDisappear(){
		//bomb.delete
		//flash
		//changeScore(50);
	}

}
